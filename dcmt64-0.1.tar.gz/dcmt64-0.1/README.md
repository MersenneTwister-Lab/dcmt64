# dcmt64
Dynamic Creator of 64bit Mersenne Twister

***UNDER CONSTRUCTION***

It is difficult for me to control MPI environment using autotools,
please modify and use src/Makefile.mpi.
